# maven-jmeter
A demo of integrating JMeter with Maven.
